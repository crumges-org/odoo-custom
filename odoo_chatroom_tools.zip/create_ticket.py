#!/usr/bin/env python3
import os
import sys
import xmlrpc.client

class OdooClient:
    def __init__(self, url, db, username, api_key):
        self.url = url
        self.db = db
        self.username = username
        self.api_key = api_key
        self.common = xmlrpc.client.ServerProxy(f'{self.url}/xmlrpc/2/common')
        self.uid = None
        self.models = xmlrpc.client.ServerProxy(f'{self.url}/xmlrpc/2/object')

    def authenticate(self):
        try:
            self.uid = self.common.authenticate(self.db, self.username, self.api_key, {})
            if not self.uid:
                raise ValueError("Authentication failed")
            return True
        except Exception as e:
            print(f"Error authenticating: {e}")
            return False

    def execute(self, model, method, *args, **kwargs):
        return self.models.execute_kw(self.db, self.uid, self.api_key, model, method, args, kwargs)

def main():
    url = os.environ.get("ODOO_TEST_URL")
    db = os.environ.get("ODOO_TEST_DB")
    user = os.environ.get("ODOO_TEST_USER")
    api_key = os.environ.get("ODOO_TEST_API_KEY")

    if not all([url, db, user, api_key]):
        print("Missing environment variables.")
        sys.exit(1)

    client = OdooClient(url, db, user, api_key)
    if not client.authenticate():
        sys.exit(1)

    # 1. Find Partner (Clypeo or Wara)
    print("Searching for partner 'Clypeo' or 'Wara'...")
    partners = client.execute('res.partner', 'search_read', ['|', ('name', 'ilike', 'Clypeo'), ('name', 'ilike', 'Wara')], ['name'], limit=5)
    
    if not partners:
        print("No partner found for Clypeo or Wara. Creating ticket without matching specific partner (or picking first available if needed).")
        # Fallback? Let's just create one or fail. The user asked for these specifically.
        # Let's try a broader search just in case, or list first 5 partners to see what exists?
        # For now, strict fail is safer than random assignment, but I will try to proceed with a placeholder or just fail.
        print("Cannot proceed without partner. Listing first 5 partners to help debug:")
        all_partners = client.execute('res.partner', 'search_read', [], ['name'], limit=5)
        for p in all_partners:
            print(f" - {p['name']}")
        sys.exit(1)
    
    partner = partners[0]
    print(f"Selected Partner: {partner['name']} (ID: {partner['id']})")

    # 2. Find/Create Tag
    tag_name = "Sin Agua"
    print(f"Searching for tag '{tag_name}'...")
    tags = client.execute('helpdesk.tag', 'search_read', [('name', '=', tag_name)], ['id'], limit=1)
    if tags:
        tag_id = tags[0]['id']
        print(f"Found existing tag ID: {tag_id}")
    else:
        print("Tag not found. Creating...")
        try:
            tag_id = client.execute('helpdesk.tag', 'create', {'name': tag_name, 'color': 1})
            print(f"Created new tag ID: {tag_id}")
        except Exception as e:
            print(f"Could not create tag (permissions?): {e}")
            tag_id = False

    # 3. Create Ticket
    ticket_vals = {
        'name': 'Falta de agua en dispenser',
        'partner_id': partner['id'],
        'description': 'El cliente reporta que se quedó sin agua en el dispenser. Favor coordinar reposición.',
        'user_id': client.uid, # Assign to self
        'tag_ids': [tag_id] if tag_id else [],
    }

    print("Creating ticket...")
    try:
        ticket_id = client.execute('helpdesk.ticket', 'create', ticket_vals)
        print(f"Ticket Created Successfully! ID: {ticket_id}")
        
        # Fetch details to display
        ticket = client.execute('helpdesk.ticket', 'read', [ticket_id], ['name', 'partner_id', 'user_id', 'stage_id'])[0]
        print(f"Ticket: {ticket.get('name')}")
        print(f"Assigned To: {ticket.get('user_id')[1]}")
        print(f"Customer: {ticket.get('partner_id')[1]}")
        print(f"Stage: {ticket.get('stage_id')[1]}")

    except Exception as e:
        print(f"Failed to create ticket: {e}")
        # Check if helpdesk.ticket exists again (sanity check)
        mod = client.execute('ir.module.module', 'search_read', [('name', '=', 'helpdesk')], ['state'])
        print(f"Helpdesk module state: {mod}")

if __name__ == "__main__":
    main()
