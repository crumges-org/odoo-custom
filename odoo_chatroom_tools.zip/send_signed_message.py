#!/usr/bin/env python3
import os
import sys
import xmlrpc.client

def main():
    url = os.environ.get("ODOO_TEST_URL")
    db = os.environ.get("ODOO_TEST_DB")
    user = os.environ.get("ODOO_TEST_USER")
    api_key = os.environ.get("ODOO_TEST_API_KEY")

    if not all([url, db, user, api_key]):
        print("Missing environment variables.")
        sys.exit(1)

    common = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/common')
    uid = common.authenticate(db, user, api_key, {})
    models = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/object', allow_none=True)

    conv_id = 64
    text = "Probando firma automatica."
    
    print(f"Sending signed message to Conversation ID {conv_id}...")
    
    try:
        # 1. Send Message
        msg_data = {
            'text': text,
            'ttype': 'text',
            'from_me': True,
        }
        # Using execute_kw and catching potential None return issues if any remaining
        try:
            models.execute_kw(db, uid, api_key, 'acrux.chat.conversation', 'send_message', [[conv_id], msg_data])
            print("Message sent.")
        except TypeError as e:
             if "cannot marshal None" in str(e):
                 print("Message sent (Void return ignored).")
             else:
                 raise e

        # 2. Verify Signature in History
        print("Fetching last message to check signature...")
        msgs = models.execute_kw(db, uid, api_key, 'acrux.chat.message', 'search_read', 
            [[('contact_id', '=', conv_id)]], 
            {'fields': ['text', 'date_message'], 'limit': 1, 'order': 'date_message desc'}
        )
        if msgs:
            last_msg = msgs[0]['text']
            print(f"Last message content:\n---\n{last_msg}\n---")
            if "Probando firma" in last_msg and len(last_msg) > len(text):
                 print("SUCCESS: Message appears longer than sent text, likely contains signature.")
            elif "Alexandra" in last_msg:  # Assuming default signature is name
                 print("SUCCESS: Signature found.")
            else:
                 print("WARNING: Signature might be missing or not in text body.")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
