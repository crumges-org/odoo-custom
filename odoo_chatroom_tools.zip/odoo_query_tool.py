#!/usr/bin/env python3
import os
import sys
import xmlrpc.client
import datetime
from pathlib import Path

class OdooClient:
    def __init__(self, url, db, username, api_key):
        self.url = url
        self.db = db
        self.username = username
        self.api_key = api_key
        self.common = xmlrpc.client.ServerProxy(f'{self.url}/xmlrpc/2/common')
        self.uid = None
        self.models = xmlrpc.client.ServerProxy(f'{self.url}/xmlrpc/2/object')

    def authenticate(self):
        try:
            self.uid = self.common.authenticate(self.db, self.username, self.api_key, {})
            if not self.uid:
                raise ValueError("Authentication failed. UID is empty.")
            print(f"Authenticated successfully. UID: {self.uid}")
            return True
        except Exception as e:
            print(f"Error authenticating: {e}")
            return False

    def execute(self, model, method, *args, **kwargs):
        if not self.uid:
            raise ValueError("Not authenticated")
        return self.models.execute_kw(self.db, self.uid, self.api_key, model, method, args, kwargs)

    def check_module_installed(self, module_name):
        domain = [('name', '=', module_name), ('state', '=', 'installed')]
        ids = self.execute('ir.module.module', 'search', domain)
        return bool(ids)

    def get_ticket_stats(self):
        # Check standard helpdesk first
        has_helpdesk = self.check_module_installed('helpdesk')
        model = 'helpdesk.ticket' if has_helpdesk else 'project.task'
        label = 'Helpdesk Tickets' if has_helpdesk else 'Project Tasks (Fallback for Tickets)'
        
        try:
            count = self.execute(model, 'search_count', [])
            # Get last 5
            last_5 = self.execute(model, 'search_read', [], ['name', 'create_date', 'stage_id'], limit=5, order='create_date desc')
            return {'label': label, 'count': count, 'recent': last_5}
        except Exception as e:
            print(f"Could not fetch data for {model}: {e}")
            return None

    def get_meeting_stats(self):
        model = 'calendar.event'
        try:
            # Meetings in the future
            now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            domain = [('start', '>=', now)]
            count = self.execute(model, 'search_count', domain)
            
            # Next 5 meetings
            next_5 = self.execute(model, 'search_read', domain, ['name', 'start', 'duration'], limit=5, order='start asc')
            return {'label': 'Upcoming Meetings', 'count': count, 'upcoming': next_5}
        except Exception as e:
            print(f"Could not fetch data for {model}: {e}")
            return None

def main():
    # Load env vars same as before or assume they are set
    # For this script we assume they are set in the environment or passed when running
    url = os.environ.get("ODOO_TEST_URL")
    db = os.environ.get("ODOO_TEST_DB")
    user = os.environ.get("ODOO_TEST_USER")
    api_key = os.environ.get("ODOO_TEST_API_KEY")

    if not all([url, db, user, api_key]):
        print("Missing environment variables: ODOO_TEST_URL, ODOO_TEST_DB, ODOO_TEST_USER, ODOO_TEST_API_KEY")
        sys.exit(1)

    client = OdooClient(url, db, user, api_key)
    if not client.authenticate():
        sys.exit(1)

    print("\n--- Odoo Data Summary ---\n")

    # Tickets/Tasks
    tickets = client.get_ticket_stats()
    if tickets:
        print(f"Model: {tickets['label']}")
        print(f"Total Count: {tickets['count']}")
        print("Recent Items:")
        for t in tickets['recent']:
             name = t.get('name')
             date = t.get('create_date')
             stage = t.get('stage_id')
             stage_name = stage[1] if stage else 'N/A'
             print(f"  - [{date}] {name} (Stage: {stage_name})")
        print("")

    # Meetings
    meetings = client.get_meeting_stats()
    if meetings:
        print(f"Model: {meetings['label']}")
        print(f"Count (Future): {meetings['count']}")
        print("Next Meetings:")
        for m in meetings['upcoming']:
            name = m.get('name') or "Meeting"
            start = m.get('start')
            print(f"  - [{start}] {name}")
        print("")

if __name__ == "__main__":
    main()
