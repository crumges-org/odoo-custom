#!/usr/bin/env python3
import os
import sys
import xmlrpc.client

def main():
    url = os.environ.get("ODOO_TEST_URL")
    db = os.environ.get("ODOO_TEST_DB")
    user = os.environ.get("ODOO_TEST_USER")
    api_key = os.environ.get("ODOO_TEST_API_KEY")

    if not all([url, db, user, api_key]):
        print("Missing environment variables.")
        sys.exit(1)

    common = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/common')
    uid = common.authenticate(db, user, api_key, {})
    models = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/object')

    print("=== Conversations Available (Last 20) ===")
    convs = models.execute_kw(db, uid, api_key, 'acrux.chat.conversation', 'search_read', 
        [[]], 
        {'fields': ['id', 'name', 'number', 'status', 'agent_id', 'last_activity'], 'limit': 20, 'order': 'last_activity desc'}
    )
    for c in convs:
        agent = c['agent_id'][1] if c['agent_id'] else "None"
        print(f"ID: {c['id']} | Name: {c['name']} | Num: {c['number']} | Status: {c['status']} | Agent: {agent}")

    print("\n=== Partners with Mobile (Last 10) ===")
    partners = models.execute_kw(db, uid, api_key, 'res.partner', 'search_read', 
        [[('mobile', '!=', False)]], 
        {'fields': ['id', 'name', 'mobile'], 'limit': 10}
    )
    for p in partners:
        print(f"ID: {p['id']} | Name: {p['name']} | Mobile: {p['mobile']}")

if __name__ == "__main__":
    main()
