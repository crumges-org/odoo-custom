#!/usr/bin/env python3
import os
import sys
import xmlrpc.client

def main():
    url = os.environ.get("ODOO_TEST_URL")
    db = os.environ.get("ODOO_TEST_DB")
    user = os.environ.get("ODOO_TEST_USER")
    api_key = os.environ.get("ODOO_TEST_API_KEY")

    if not all([url, db, user, api_key]):
        print("Missing environment variables.")
        sys.exit(1)

    common = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/common')
    uid = common.authenticate(db, user, api_key, {})
    models = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/object', allow_none=True)

    print(f"Checking settings for User ID {uid}...")
    
    # 1. Check User Settings
    user_fields = ['name', 'chatroom_signing_active', 'chatroom_signing']
    user_data = models.execute_kw(db, uid, api_key, 'res.users', 'read', [[uid], user_fields])[0]
    print(f"User: {user_data['name']}")
    print(f" - Signing Active: {user_data['chatroom_signing_active']}")
    print(f" - Custom Signature: {user_data['chatroom_signing']}")

    if not user_data['chatroom_signing_active']:
        print(" -> Activating signature for user...")
        models.execute_kw(db, uid, api_key, 'res.users', 'write', [[uid], {'chatroom_signing_active': True}])
        print(" -> Done.")
    
    # 2. Check Connector Settings (for Conversation 64)
    conv_fields = ['connector_id']
    conv_data = models.execute_kw(db, uid, api_key, 'acrux.chat.conversation', 'read', [[64], conv_fields])[0]
    conn_id = conv_data['connector_id'][0]
    
    conn_fields = ['name', 'allow_signing']
    conn_data = models.execute_kw(db, uid, api_key, 'acrux.chat.connector', 'read', [[conn_id], conn_fields])[0]
    print(f"Connector: {conn_data['name']}")
    print(f" - Allow Signing: {conn_data['allow_signing']}")

    if not conn_data['allow_signing']:
        print(" -> Activating signing on connector...")
        models.execute_kw(db, uid, api_key, 'acrux.chat.connector', 'write', [[conn_id], {'allow_signing': True}])
        print(" -> Done.")

if __name__ == "__main__":
    main()
