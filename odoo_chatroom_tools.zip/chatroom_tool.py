#!/usr/bin/env python3
import os
import sys
import xmlrpc.client
import datetime
import time

class OdooChatClient:
    def __init__(self, url, db, username, api_key):
        self.url = url
        self.db = db
        self.username = username
        self.api_key = api_key
        self.common = xmlrpc.client.ServerProxy(f'{self.url}/xmlrpc/2/common')
        self.uid = None
        self.models = xmlrpc.client.ServerProxy(f'{self.url}/xmlrpc/2/object')

    def authenticate(self):
        try:
            self.uid = self.common.authenticate(self.db, self.username, self.api_key, {})
            if not self.uid:
                raise ValueError("Authentication failed")
            return True
        except Exception as e:
            print(f"Error authenticating: {e}")
            return False

    def execute(self, model, method, *args, **kwargs):
        return self.models.execute_kw(self.db, self.uid, self.api_key, model, method, args, kwargs)

    def get_my_chats(self):
        # Search for chats assigned to me or new
        domain = [
            '|', 
            ('status', '=', 'new'),
            '&', ('status', '=', 'current'), ('agent_id', '=', self.uid)
        ]
        fields = ['name', 'number', 'status', 'last_activity', 'agent_id']
        return self.execute('acrux.chat.conversation', 'search_read', domain, fields, limit=20, order='last_activity desc')

    def get_messages(self, conversation_id, limit=20):
        domain = [('contact_id', '=', conversation_id)]
        fields = ['text', 'date_message', 'from_me', 'ttype', 'contact_name']
        messages = self.execute('acrux.chat.message', 'search_read', domain, fields, limit=limit, order='date_message desc')
        return list(reversed(messages)) # Return oldest first for display

    def send_message(self, conversation_id, text):
        # Prepare message data as per Acrux module requirement
        msg_data = {
            'text': text,
            'ttype': 'text',
            'from_me': True,
        }
        try:
            # We call the method 'send_message' on the conversation record
            # args: [ids], msg_data
            self.execute('acrux.chat.conversation', 'send_message', [conversation_id], msg_data)
            return True
        except Exception as e:
            print(f"Error sending message: {e}")
            return False

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    url = os.environ.get("ODOO_TEST_URL")
    db = os.environ.get("ODOO_TEST_DB")
    user = os.environ.get("ODOO_TEST_USER")
    api_key = os.environ.get("ODOO_TEST_API_KEY")

    if not all([url, db, user, api_key]):
        print("Missing environment variables.")
        sys.exit(1)

    client = OdooChatClient(url, db, user, api_key)
    if not client.authenticate():
        sys.exit(1)

    while True:
        clear_screen()
        print("=== Odoo Chatroom Console ===")
        print(f"User ID: {client.uid}")
        print("-" * 30)
        
        chats = client.get_my_chats()
        if not chats:
            print("No active chats found.")
        
        for i, chat in enumerate(chats):
            status_icon = "🆕" if chat['status'] == 'new' else "💬"
            agent = chat['agent_id'][1] if chat['agent_id'] else "Unassigned"
            print(f"{i+1}. {status_icon} {chat['name']} ({chat['number']}) - {chat['status']} [{agent}]")
            print(f"   Last Activity: {chat['last_activity']}")

        print("-" * 30)
        print("Enter Chat Number (1-N), 'r' to refresh, or 'q' to quit.")
        choice = input("> ").strip().lower()

        if choice == 'q':
            break
        elif choice == 'r':
            continue
        
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(chats):
                selected_chat = chats[idx]
                chat_loop(client, selected_chat)
        except ValueError:
            pass

def chat_loop(client, chat):
    while True:
        clear_screen()
        print(f"--- Chat: {chat['name']} ({chat['number']}) ---")
        messages = client.get_messages(chat['id'])
        
        for msg in messages:
            actor = "Me" if msg['from_me'] else (msg['contact_name'] or chat['name'])
            timestamp = msg['date_message']
            content = msg['text'] or f"[{msg['ttype']}]"
            print(f"[{timestamp}] {actor}: {content}")
        
        print("-" * 30)
        print("Type message (or 'back' to list, 'r' to refresh):")
        text = input("> ").strip()
        
        if text.lower() == 'back':
            break
        elif text.lower() == 'r':
            continue
        elif text:
            print("Sending...")
            if client.send_message(chat['id'], text):
                print("Sent!")
            else:
                input("Failed to send. Press Enter...")

if __name__ == "__main__":
    main()
