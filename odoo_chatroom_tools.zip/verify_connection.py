#!/usr/bin/env python3
import os
import sys
import requests
from pathlib import Path

# NOTE: Environment loading logic preserved but I will inject env vars when running
env_path = Path.home() / '.env'
if env_path.exists():
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if '=' not in line:
            continue
        k, v = line.split('=', 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        os.environ.setdefault(k, v)

url = os.environ.get("ODOO_TEST_URL")
db = os.environ.get("ODOO_TEST_DB")
user = os.environ.get("ODOO_TEST_USER")
api_key = os.environ.get("ODOO_TEST_API_KEY")

if not all([url, db, user, api_key]):
    print("Faltan variables: ODOO_TEST_URL / ODOO_TEST_DB / ODOO_TEST_USER / ODOO_TEST_API_KEY", file=sys.stderr)
    sys.exit(1)

session = requests.Session()

payload = {
    "jsonrpc": "2.0",
    "method": "call",
    "params": {
        "db": db,
        "login": user,
        "password": api_key,
    },
}

try:
    resp = session.post(f"{url}/web/session/authenticate", json=payload, timeout=15)
except Exception as e:
    print(f"Error de red al conectar con Odoo: {e}", file=sys.stderr)
    sys.exit(1)

if resp.status_code != 200:
    print(f"HTTP error: {resp.status_code}", file=sys.stderr)
    sys.exit(1)

try:
    data = resp.json()
except Exception as e:
    print(f"Respuesta no es JSON válido: {e}", file=sys.stderr)
    print(resp.text[:500], file=sys.stderr)
    sys.exit(1)

if data.get("error"):
    print("Error al autenticar:", data["error"], file=sys.stderr)
    sys.exit(1)

uid = data.get("result", {}).get("uid")
if not uid:
    print("No se pudo obtener uid de sesión", file=sys.stderr)
    sys.exit(1)

print(f"Conexión OK a Odoo test. UID = {uid}")
