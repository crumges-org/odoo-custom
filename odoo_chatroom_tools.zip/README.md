# Odoo Query Tools & Chatroom Console

This directory contains tools to connect to, query, and interact with your Odoo instance using its external API.

## Tools

### 1. `chatroom_tool.py` (New!)
A console-based interface to interact with the Acruxlab Chatroom module.
- **List Chats**: View active conversations assigned to you.
- **Read History**: View past messages.
- **Send Messages**: Reply to users directly from the console (supports automatic signature).
- **Usage**:
  ```bash
  python3 chatroom_tool.py
  ```

### 2. `create_ticket.py`
A script to automate ticket creation.
- Finds/Creates tags (e.g., "Sin Agua").
- Searches for specific customers.
- Creates a ticket and logs the result.

### 3. `odoo_query_tool.py`
A robust query tool using Odoo's standard `xmlrpc` interface.
- Retrieves counts of Tickets/Tasks and future Meetings.
- Lists recent items.

### 4. `verify_connection.py`
A simple script to verify your credentials and connection.

## Development Utilities
Helper scripts used for testing and configuration:
- `check_signature_settings.py`: Checks and enables user signature settings.
- `list_chat_targets.py`: Lists potential conversation targets.
- `send_signed_message.py` & `send_test_mario.py`: Tests for message sending.

## Environment Variables
All scripts require the following environment variables:
- `ODOO_TEST_URL`: URL of the Odoo instance (e.g., https://test-crumges.cumbre.ar)
- `ODOO_TEST_DB`: Database name
- `ODOO_TEST_USER`: User email/login
- `ODOO_TEST_API_KEY`: User API Key or Password

## Replicating on GitHub
To move this to a GitHub repository:
1. Create a new repository.
2. Copy all `.py` files.
3. Create a `requirements.txt` containing:
   ```
   requests
   ```
   (Note: `xmlrpc` is part of Python standard library).
4. Add this README.
