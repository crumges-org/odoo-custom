#!/usr/bin/env python3
import os
import sys
import xmlrpc.client

def main():
    url = os.environ.get("ODOO_TEST_URL")
    db = os.environ.get("ODOO_TEST_DB")
    user = os.environ.get("ODOO_TEST_USER")
    api_key = os.environ.get("ODOO_TEST_API_KEY")

    if not all([url, db, user, api_key]):
        print("Missing environment variables.")
        sys.exit(1)

    # Use allow_none=True to prevent marshalling errors when Odoo returns None
    common = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/common')
    uid = common.authenticate(db, user, api_key, {})
    
    # Re-initialize models proxy with allow_none=True might not help if server doesn't support it,
    # but the error is client-side 'dumps'. 
    models = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/object', allow_none=True)

    conv_id = 64
    text = "Hola Mario, esta es una prueba desde la consola de Odoo."
    
    print(f"Conversation ID: {conv_id}")
    
    try:
        # 1. Set to Current (Re-open)
        print("Re-opening conversation (Set to Current)...")
        # Explicitly ignore return if it fails due to None, or use execute_kw
        try:
            models.execute_kw(db, uid, api_key, 'acrux.chat.conversation', 'set_to_current', [[conv_id]])
            print("Conversation re-opened.")
        except xmlrpc.client.Fault as e:
            # Check if it's the "cannot marshal None" error hidden in Fault, or just print
            print(f"Warning during re-open (might be success): {e}")
        except TypeError as e:
             if "cannot marshal None" in str(e):
                 print("Conversation re-opened (Void return ignored).")
             else:
                 raise e

        # 2. Send Message
        print(f"Sending message...")
        msg_data = {
            'text': text,
            'ttype': 'text',
            'from_me': True,
        }
        models.execute_kw(db, uid, api_key, 'acrux.chat.conversation', 'send_message', [[conv_id], msg_data])
        print("Message sent successfully!")
        
        # 3. Verify
        print("Fetching last message...")
        msgs = models.execute_kw(db, uid, api_key, 'acrux.chat.message', 'search_read', 
            [[('contact_id', '=', conv_id)]], 
            {'fields': ['text', 'date_message'], 'limit': 1, 'order': 'date_message desc'}
        )
        if msgs:
            print(f"Last message: {msgs[0]['text']} at {msgs[0]['date_message']}")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
